angular.module('starter.services')

.service('AceWebService', function($http) {
	return {
			
	};
});